## Core Components

API Gateway, Policy Engine, Model Router, Execution, Observability.
