## API Specifications

Unified APIs for ASR, NMT, TTS, LLM, OCR.
