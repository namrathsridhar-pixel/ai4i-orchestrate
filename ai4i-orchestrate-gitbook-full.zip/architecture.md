## Architecture

Layered architecture separating governance, routing, and execution.
